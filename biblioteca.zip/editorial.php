<div class="col-sm-8">

<?
$campo2=$_POST['campo2'];


if(strlen($campo2)>0){
$sql="SELECT codigo,nombre,logo
FROM tbleditorial where nombre like '$campo2%'";
include 'config/conexion.php';
$registro=mysqli_query($con,$sql) or die('Error en sql');
echo '<center><table><tr><td>codigo</td><td>nombre</td><td></td></tr>';
  while($r=mysqli_fetch_array($registro)){
    echo "<tr><td>" .$r['codigo']. "</td><td>" .$r['nombre']."</td><td>" .$r['logo']. "</td><td><img src=img/".$r['logo']."></td>
     </tr>";
  }
}
?>

</table>
  </center>
</div>