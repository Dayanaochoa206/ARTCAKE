<div class="col-sm-6">
<?
$campo=$_POST['campo'];
echo ''. $campo;
// incluir conexion
if(strlen($campo)>0){
  $sql="SELECT nombre,ubicacion,cons,
      ISBN,id_autor,id_editorial,npaginas,caratula  
       FROM tbllibros where nombre like  '$campo%'";
include 'config/conexion.php';
$registro=mysqli_query($con,$sql) or die('Error en sql');
echo '<table><tr><td>ISBN</td><td>Nombre</td><td></td></tr>';
while($r=mysqli_fetch_array($registro)){
  echo "<tr><td>".$r['ISBN']."</td><td>".$r['nombre']."</td>
        <td><img src=img/".$r['caratula']."></td>
        </tr>";
}
}
?>

</table>
    </div>
                                                                                                                                                                                                                                     