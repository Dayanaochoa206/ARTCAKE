<div class="jumbotron text-center">
  <h1>Biblioteca</h1>
    <p>Fe y Alegria Aures 2</p> 
  <p>
    <img src="imagenes/logo.png">
  </p>
</div>