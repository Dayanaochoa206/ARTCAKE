<?
$host="btfmzkqsolmrdiezncg7-mysql.services.clever-cloud.com";
$bd="btfmzkqsolmrdiezncg7";
$user="uvkfaq3h4b2ne9pn";
$pwd="wgYdwKPaCnMG7ctaYSq8";
$con=mysqli_connect($host,$user,$pwd,$bd) or 
  die("Problemas en la conexión");
?>